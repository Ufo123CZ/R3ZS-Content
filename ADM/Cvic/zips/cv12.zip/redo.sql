SELECT 
    l.GROUP# AS LOG_GROUP,
    case 
    when count(*)>1 then count(*)||' OK' 
    else count(*)||' ERROR' end POCET
FROM 
    V$LOG l, V$LOGFILE lf
    where l.GROUP# = lf.GROUP#
    group by l.GROUP#
ORDER BY 
    l.GROUP#;