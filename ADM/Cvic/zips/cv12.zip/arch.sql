SELECT 
case
when count(*)>1 then count(*)||' OK'
else count(*)||' ERROR'
end archivelog_dets 
FROM 
    V$ARCHIVE_DEST
WHERE 
    STATUS = 'VALID' -- Pouze aktivní a platné destinace
ORDER BY 
    DEST_ID;