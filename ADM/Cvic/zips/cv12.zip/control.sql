select 
case
when count(*)>1 then count(*)||' OK'
else count(*)||' Chyba' 
end controlfiles from v$controlfile;