SELECT
    bs.START_TIME AS BACKUP_DATE,
    bs.COMPLETION_TIME AS BACKUP_COMPLETION,
    bp.HANDLE AS BACKUP_LOCATION,
    bdf.CHECKPOINT_CHANGE# AS SCN,
    CASE
        WHEN bs.CONTROLFILE_INCLUDED = 'YES' THEN 'Autobackup'
        ELSE CASE
            WHEN bs.BACKUP_TYPE = 'D' THEN 'Datafile Backupset'
            WHEN bs.BACKUP_TYPE = 'I' THEN 'Incremental Backupset'
            WHEN bs.BACKUP_TYPE = 'L' THEN 'Archive Log Backupset'
            ELSE 'Other Backupset'
        END
    END AS BACKUP_TYPE
FROM V$BACKUP_SET bs, V$BACKUP_PIECE bp,  V$BACKUP_DATAFILE bdf
where  bs.SET_STAMP = bp.SET_STAMP AND bs.SET_COUNT = bp.SET_COUNT
AND    bs.SET_STAMP = bdf.SET_STAMP AND bs.SET_COUNT = bdf.SET_COUNT
ORDER By  bs.START_TIME DESC;
